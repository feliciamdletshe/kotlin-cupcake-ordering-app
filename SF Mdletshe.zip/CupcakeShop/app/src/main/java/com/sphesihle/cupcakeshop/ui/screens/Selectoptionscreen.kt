package com.sphesihle.cupcakeshop.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.sphesihle.cupcakeshop.R

/**
 * Reusable option-selection screen used for both:
 *   - Screen 2 – Choose Flavor
 *   - Screen 3 – Choose Pickup Date
 *
 * Displays a list of radio-button options, a subtotal, and Cancel/Next buttons.
 *
 * @param subtotal         Formatted price string shown at the bottom.
 * @param options          The list of selectable strings (flavors or dates).
 * @param onSelectionChanged  Invoked whenever the user picks a different option.
 * @param onNextButtonClicked Invoked when the user taps "Next" (only enabled after selection).
 * @param onCancelButtonClicked Invoked when the user taps "Cancel".
 * @param modifier         Optional [Modifier].
 */
@Composable
fun SelectOptionScreen(
    subtotal: String,
    options: List<String>,
    onSelectionChanged: (String) -> Unit,
    onNextButtonClicked: () -> Unit,
    onCancelButtonClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Track which option is currently selected; null means nothing is selected yet
    var selectedValue by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = modifier
            .padding(16.dp)
            .fillMaxHeight(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // ── Radio button list ──────────────────────────────────────────────────
        Column(modifier = Modifier.padding(top = 8.dp)) {
            options.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(
                            selected = selectedValue == item,
                            onClick = {
                                selectedValue = item
                                onSelectionChanged(item)
                            },
                            role = Role.RadioButton
                        )
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedValue == item,
                        onClick = null
                    )
                    Text(
                        text = item,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }

        // ── Subtotal + buttons ─────────────────────────────────────────────────
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.End
        ) {
            // Subtotal label aligned to the end
            Text(
                text = stringResource(R.string.subtotal_price, subtotal),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Divider(modifier = Modifier.padding(bottom = 8.dp))

            // Cancel / Next button row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Cancel returns the user to the Start screen and clears the order
                OutlinedButton(
                    modifier = Modifier.weight(1f),
                    onClick = onCancelButtonClicked
                ) {
                    Text(stringResource(R.string.cancel))
                }

                // Next is only enabled once an option has been selected
                Button(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                    enabled = selectedValue.isNotEmpty(),
                    onClick = onNextButtonClicked
                ) {
                    Text(stringResource(R.string.next))
                }
            }
        }
    }
}

// ── Preview ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true)
@Composable
fun SelectOptionScreenPreview() {
    SelectOptionScreen(
        subtotal = "$12.00",
        options = listOf("Vanilla", "Chocolate", "Red Velvet", "Salted Caramel", "Coffee"),
        onSelectionChanged = {},
        onNextButtonClicked = {},
        onCancelButtonClicked = {}
    )
}