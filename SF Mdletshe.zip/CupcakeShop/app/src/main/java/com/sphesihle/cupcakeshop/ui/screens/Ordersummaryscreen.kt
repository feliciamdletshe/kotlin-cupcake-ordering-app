package com.sphesihle.cupcakeshop.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.sphesihle.cupcakeshop.R
import com.sphesihle.cupcakeshop.data.OrderUiState

/**
 * Screen 4 – Order Summary Screen.
 *
 * Displays a read-only summary of the completed order:
 *   • Quantity, Flavor, Pickup Date, and Total Price.
 *
 * The Cancel button clears the order and returns to the Start screen.
 *
 * @param orderUiState       The current order state collected from [OrderViewModel].
 * @param onCancelButtonClicked Callback invoked when the user taps "Cancel".
 * @param modifier           Optional [Modifier].
 */
@Composable
fun OrderSummaryScreen(
    orderUiState: OrderUiState,
    onCancelButtonClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .padding(16.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {

            Spacer(modifier = Modifier.height(8.dp))

            // ── QUANTITY ───────────────────────────────────────────────────────
            OrderSummaryRow(
                label = stringResource(R.string.quantity).uppercase(),
                value = "${orderUiState.quantity} cupcakes"
            )

            Divider(modifier = Modifier.padding(vertical = 4.dp))

            // ── FLAVOR ────────────────────────────────────────────────────────
            OrderSummaryRow(
                label = stringResource(R.string.flavor).uppercase(),
                value = orderUiState.flavor
            )

            Divider(modifier = Modifier.padding(vertical = 4.dp))

            // ── PICKUP DATE ───────────────────────────────────────────────────
            OrderSummaryRow(
                label = stringResource(R.string.pickup_date).uppercase(),
                value = orderUiState.date
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── SUBTOTAL ──────────────────────────────────────────────────────
            Text(
                text = stringResource(R.string.subtotal_price, orderUiState.price),
                modifier = Modifier.align(Alignment.End)
            )
        }

        // ── Cancel button (full width, at the bottom) ──────────────────────────
        Button(
            onClick = onCancelButtonClicked,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp)
        ) {
            Text(stringResource(R.string.cancel))
        }
    }
}

/**
 * Helper composable that renders one labelled row on the summary screen.
 *
 * @param label The field name (e.g. "QUANTITY").
 * @param value The field value (e.g. "12 cupcakes").
 */
@Composable
private fun OrderSummaryRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(vertical = 4.dp)) {
        Text(text = label)
        Text(text = value, fontWeight = FontWeight.Bold)
    }
}

// ── Preview ───────────────────────────────────────────────────────────────────

@Preview(showBackground = true)
@Composable
fun OrderSummaryScreenPreview() {
    OrderSummaryScreen(
        orderUiState = OrderUiState(
            quantity = 12,
            flavor = "Coffee",
            date = "Fri Nov 17",
            price = "$24.00"
        ),
        onCancelButtonClicked = {}
    )
}