package com.sphesihle.cupcakeshop.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.sphesihle.cupcakeshop.R
import com.sphesihle.cupcakeshop.ui.screens.CupcakeScreen
import com.sphesihle.cupcakeshop.ui.screens.SelectOptionScreen
import com.sphesihle.cupcakeshop.ui.screens.StartOrderScreen
import com.sphesihle.cupcakeshop.ui.viewmodel.OrderViewModel
import androidx.compose.ui.res.stringResource
import com.sphesihle.cupcakeshop.ui.screens.OrderSummaryScreen


/**
 * Defines the navigation graph for the Cupcake app.
 *
 * Extracted from [CupcakeApp] so that the NavHost lives in its own file,
 * keeping the app-level composable focused solely on the Scaffold/TopAppBar
 * and making the graph easier to read and maintain independently.
 *
 * @param navController The [NavHostController] shared with [CupcakeApp].
 * @param viewModel     The shared [OrderViewModel] injected by [CupcakeApp].
 * @param modifier      Passed in from the Scaffold's innerPadding slot.
 */
@Composable
fun CupcakeNavGraph(
    navController: NavHostController,
    viewModel: OrderViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    NavHost(
        navController = navController,
        startDestination = CupcakeScreen.Start.name,
        modifier = modifier
            .fillMaxSize()
    ) {

        // ── Screen 1: Start Order ──────────────────────────────────────────────
        composable(route = CupcakeScreen.Start.name) {
            StartOrderScreen(
                quantityOptions = listOf(
                    Pair(R.string.one_cupcake, 1),
                    Pair(R.string.six_cupcakes, 6),
                    Pair(R.string.twelve_cupcakes, 12)
                ),
                onNextButtonClicked = { quantity ->
                    viewModel.setQuantity(quantity)
                    navController.navigate(CupcakeScreen.Flavor.name)
                }
            )
        }

        // ── Screen 2: Choose Flavor ────────────────────────────────────────────
        composable(route = CupcakeScreen.Flavor.name) {
            SelectOptionScreen(
                subtotal = uiState.price,
                options = listOf(
                    stringResource(R.string.vanilla),
                    stringResource(R.string.chocolate),
                    stringResource(R.string.red_velvet),
                    stringResource(R.string.salted_caramel),
                    stringResource(R.string.coffee)
                ),
                onSelectionChanged = { viewModel.setFlavor(it) },
                onNextButtonClicked = { navController.navigate(CupcakeScreen.Pickup.name) },
                onCancelButtonClicked = {
                    cancelOrderAndNavigateToStart(viewModel, navController)
                }
            )
        }

        // ── Screen 3: Choose Pickup Date ───────────────────────────────────────
        composable(route = CupcakeScreen.Pickup.name) {
            SelectOptionScreen(
                subtotal = uiState.price,
                options = uiState.pickupOptions,
                onSelectionChanged = { viewModel.setDate(it) },
                onNextButtonClicked = { navController.navigate(CupcakeScreen.Summary.name) },
                onCancelButtonClicked = {
                    cancelOrderAndNavigateToStart(viewModel, navController)
                }
            )
        }

        // ── Screen 4: Order Summary ────────────────────────────────────────────
        composable(route = CupcakeScreen.Summary.name) {
            OrderSummaryScreen(
                orderUiState = uiState,
                onCancelButtonClicked = {
                    cancelOrderAndNavigateToStart(viewModel, navController)
                }
            )
        }
    }
}

/**
 * Resets the order state and pops the back stack back to the Start screen.
 * Private to this file — [CupcakeApp] triggers this indirectly via callbacks.
 */
private fun cancelOrderAndNavigateToStart(
    viewModel: OrderViewModel,
    navController: NavHostController
) {
    viewModel.resetOrder()
    navController.popBackStack(CupcakeScreen.Start.name, inclusive = false)
}