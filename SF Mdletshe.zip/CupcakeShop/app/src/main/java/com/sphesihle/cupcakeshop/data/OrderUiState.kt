package com.sphesihle.cupcakeshop.data

/** Price per cupcake */
 const val PRICE_PER_CUPCAKE = 2.00

/** Extra charge for same-day pickup */
 const val PRICE_FOR_SAME_DAY_PICKUP = 3.00

/**
 * Data class representing the complete state of a cupcake order.
 */
data class OrderUiState(
    val quantity: Int = 0,
    val flavor: String = "",
    val date: String = "",
    val price: String = "",
    val pickupOptions: List<String> = listOf()
)
